﻿using EntityFrameworkCoreMock;
using JewelryStore.Context;
using JewelryStore.Facades;
using JewelryStore.Models;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System.Linq;

namespace JewelryStoreTest.Facades
{
    public class UserFacadeTest
    {
        private Mock<JewelryContext> _jewelryContext;
        private DbContextMock<JewelryContext> _dbContextMock;
        private DbContextOptions<JewelryContext> DummyOptions { get; } = new DbContextOptionsBuilder<JewelryContext>().Options;
        //private AdminFacade _adminFacade;

        [SetUp]
        public void Setup()
        {
            _jewelryContext = new Mock<JewelryContext>();
            _dbContextMock = new DbContextMock<JewelryContext>(DummyOptions);
        }


        [TestCase("privileged", "privileged", "privileged","Test")]
        [TestCase("admin", "admin", "admin", "Test12")]
        [TestCase("normal", "normal", "normal", "Test456")]
        public void UpdatePasswordTest(string userName, string password, string role, string testPassword)
        {
            var initialEntities = new[]
            {
                new UserDetails {  UserName = userName, Password = password , Role = role}
            };


            var usersDbSetMock = _dbContextMock.CreateDbSetMock(x => x.UserDetails, initialEntities);

            var userFacade = new UserFacade(_dbContextMock.Object);
            var response = userFacade.UpdatePassword(userName, password, testPassword);

            var UpdatedRecord = _dbContextMock.Object.UserDetails.Where(z => z.UserName == userName).FirstOrDefault();
            Assert.AreEqual(response.Value, "SuccessFul");
            
            Assert.AreEqual(userName, UpdatedRecord.UserName);
            Assert.AreEqual(role, UpdatedRecord.Role);
            Assert.AreEqual(testPassword, UpdatedRecord.Password);

        }

        [TestCase("normal", "normal1", "normal", "Test456")]
        public void UpdatePasswordTestFailed(string userName, string password, string role, string testPassword)
        {
            var initialEntities = new[]
            {
                new UserDetails {  UserName = userName, Password = "test" , Role = role}
            };


            var usersDbSetMock = _dbContextMock.CreateDbSetMock(x => x.UserDetails, initialEntities);

            var userFacade = new UserFacade(_dbContextMock.Object);
            var response = userFacade.UpdatePassword(userName, password, testPassword);

            var UpdatedRecord = _dbContextMock.Object.UserDetails.Where(z => z.UserName == userName).FirstOrDefault();
            Assert.AreEqual(response.Value, "User Name or Password Doesnot Match");

            Assert.AreEqual(userName, UpdatedRecord.UserName);
            Assert.AreEqual(role, UpdatedRecord.Role);
            Assert.AreNotEqual(password, UpdatedRecord.Password);
            Assert.AreNotEqual(testPassword, UpdatedRecord.Password);

        }

        [TestCase("privileged",2)]
        [TestCase("admin", 13)]
        public void GetDiscountTest(string userName, int discountPercent)
        {
            var initialEntities = new[]
            {
                new Discount {  UpdatedBy = userName, DiscountPercent = discountPercent }
            };

            var usersDbSetMock = _dbContextMock.CreateDbSetMock(x => x.Discount, initialEntities);

            var userFacade = new UserFacade(_dbContextMock.Object);
            var response = userFacade.GetDiscount();

            Assert.AreEqual(discountPercent.ToString(), response.Value);

        }

    }
}

﻿using EntityFrameworkCoreMock;
using JewelryStore.Context;
using JewelryStore.Facades;
using JewelryStore.Models;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System.Linq;

namespace JewelryStoreTest.Facades
{
    public class AdminFacadeTest
    {
        private Mock<JewelryContext> _jewelryContext;
        private DbContextMock<JewelryContext> _dbContextMock;
        private DbContextOptions<JewelryContext> DummyOptions { get; } = new DbContextOptionsBuilder<JewelryContext>().Options;
        //private AdminFacade _adminFacade;

        [SetUp]
        public void Setup()
        {
            _jewelryContext = new Mock<JewelryContext>();
             _dbContextMock = new DbContextMock<JewelryContext>(DummyOptions);
        }


        [TestCase("admin", 3)]
        [TestCase("admin", 13)]
        [TestCase("admin", 4)]
        public void UpdateDiscountTest(string userName, int discountPercent)
        {
            var initialEntities = new[]
            {
                new Discount {  UpdatedBy = "Admin", DiscountPercent = 2 }
            };

          
            var usersDbSetMock = _dbContextMock.CreateDbSetMock(x => x.Discount, initialEntities);

            var adminFacade = new AdminFacade(_dbContextMock.Object);
            var countData = _dbContextMock.Object.Discount.Count();
            var response = adminFacade.UpdateDiscount(userName, discountPercent);

            var CountNew = _dbContextMock.Object.Discount.Count();
            var UpdatedRecord = _dbContextMock.Object.Discount.Last();
            Assert.IsInstanceOf<string>(response);
            Assert.AreEqual(countData+1,CountNew);
            Assert.AreEqual(userName, UpdatedRecord.UpdatedBy);
            Assert.AreEqual(discountPercent, UpdatedRecord.DiscountPercent);

        }

    }
}

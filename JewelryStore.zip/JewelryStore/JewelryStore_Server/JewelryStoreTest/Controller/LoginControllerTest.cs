﻿using JewelryStore.Controllers;
using JewelryStore.Models;
using JewelryStore.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;

namespace JewelryStoreTest.Controller
{
    public class LoginControllerTest
    {
        private Mock<IOAuthService> _oAuthServiceMock;
        private LoginController _loginController;
        private const string token = "eyJhbGciOiJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGRzaWctbW9yZSNobWFjLXNoYTI1NiIsInR5cCI6IkpXVCJ9." +
            "eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiMSIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC" +
            "5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvcm9sZSI6IlByaXZpbGFnZWQiLCJleHAiOjE2MTE0NTc3MDEsImlzcyI6Ikpld2VscnlBZG1pbiIsImF1Z" +
            "CI6Ikpld2VscnlBcGkifQ.NkNvldShziyTCYIFb_k5ZodumbK-lvA-7Qffg0fqdgQ";

        [SetUp]
        public void Setup()
        {
            _oAuthServiceMock = new Mock<IOAuthService>();
            _loginController = new LoginController(_oAuthServiceMock.Object);
        }


        [TestCase("privileged", "123")]
        [TestCase("admin", "123")]
        [TestCase("normal", "1234")]
        public void GetAllPaymentsObjectTypeTest(string userName, String password)
        {
            _oAuthServiceMock.Setup(x => x.ValidateAndGetToken(userName, password)).Returns(token);

            var userCredentials = new UserCredentials() { userName = userName, password = password };
            var response = _loginController.Login(userCredentials);

            Assert.IsInstanceOf<OkObjectResult>(response.Result);
        }

        [Test]
        public void GetAllPaymentsBadObjectTypeTest()
        {
            var userCredentials = new UserCredentials() { userName = "admin", password = "123" };

            _oAuthServiceMock.Setup(x => x.ValidateAndGetToken("admin", "123")).Throws(new Exception());
            var response = _loginController.Login(userCredentials);

            Assert.IsInstanceOf<BadRequestObjectResult>(response.Result);

        }

    }
}

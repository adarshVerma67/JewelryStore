﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JewelryStore.Models
{
    public class UserCredentials
    {
        public string userName { get; set; }
        public string password { get; set; }
    }
}

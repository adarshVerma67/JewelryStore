﻿using Newtonsoft.Json;

namespace JewelryStore.Models
{
    public class AccessTokenTemplate
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }
    }
}

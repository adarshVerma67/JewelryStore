﻿using JewelryStore.Facades;
using JewelryStore.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace JewelryStore.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        /// <summary>
        /// Facade Contest Class
        /// </summary>
        private readonly UserFacade _userFacade;
        public UsersController(UserFacade userFacade)
        {
            _userFacade = userFacade;
        }

        /// <summary>
        /// Updates the Password
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">password</param>
        /// <param name="newPassword">new password</param>
        /// <returns>ActionResult<string></returns>
        [HttpPost]
        public ActionResult<string> UpdatePassword(string userName, String password, String newPassword)
        {
            return Ok(_userFacade.UpdatePassword(userName, password, newPassword));
        }

        /// <summary>
        /// Gets Discount
        /// </summary>
        /// <returns>ActionResult<string></returns>
        [Authorize(Roles = Role.Privileged)]
        [HttpGet]
        public ActionResult<string> GetDiscount()
        {
            try
            {
                return Ok(_userFacade.GetDiscount());

            }
            catch (Exception)
            {

                return StatusCode(500);
            }
           
        }
    }
}

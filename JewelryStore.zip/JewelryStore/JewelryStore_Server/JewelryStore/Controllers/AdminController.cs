﻿using JewelryStore.Facades;
using JewelryStore.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;

namespace JewelryStore.Controllers
{
    [Authorize(Roles = Role.Admin)]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        /// <summary>
        /// Facade Contest Class
        /// </summary>
        private readonly AdminFacade _adminFacade;
        public AdminController(AdminFacade adminFacade)
        {
            _adminFacade = adminFacade;
        }

        /// <summary>
        /// Updates Discount
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="discountPercent">discountPercent</param>
        /// <returns>ActionResult<string></returns>
        [HttpPost]
        public ActionResult<string> UpdateDiscount(string userName, int discountPercent)
        {
            try
            {
                return Ok(_adminFacade.UpdateDiscount(userName, discountPercent));
            }
            catch (Exception)
            {

                return BadRequest("Invalid Operation Contact Admin");
            }
            
        }
    }
}

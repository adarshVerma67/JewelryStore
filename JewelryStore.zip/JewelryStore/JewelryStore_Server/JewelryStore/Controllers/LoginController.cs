﻿using JewelryStore.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;

namespace JewelryStore.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        /// <summary>
        /// Auth service Contest Class
        /// </summary>
        private readonly IOAuthService _oAuthService;

        public LoginController(IOAuthService oAuthService)
        {
            _oAuthService = oAuthService;
        }

        /// <summary>
        /// Login
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">password</param>
        /// <returns>ActionResult<string></returns>
        [AllowAnonymous]
        [HttpPost]
        public ActionResult<string> Login([FromBody]JewelryStore.Models.UserCredentials userCredentials)
        {
            string token;
            try
            {
                 token = _oAuthService.ValidateAndGetToken(userCredentials.userName, userCredentials.password);

            }
            catch (Exception)
            {
                return BadRequest("Invalid Operation"); 
            }
           
            return Ok(token);
        }
    }
}

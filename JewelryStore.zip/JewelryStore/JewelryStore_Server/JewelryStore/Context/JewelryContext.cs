﻿using JewelryStore.Models;
using Microsoft.EntityFrameworkCore;

namespace JewelryStore.Context
{
    public class JewelryContext :DbContext
    {
        public JewelryContext(DbContextOptions options):base(options)
        {

        }
      
        public virtual  DbSet<UserDetails> UserDetails { get; set; }
        public virtual DbSet<Discount> Discount { get; set; }
    }
}

﻿using JewelryStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JewelryStore.Services
{
  public  interface IOAuthService
    {
        string GetToken(UserDetails user);
        string ValidateAndGetToken(string userName, string password);
    }
}

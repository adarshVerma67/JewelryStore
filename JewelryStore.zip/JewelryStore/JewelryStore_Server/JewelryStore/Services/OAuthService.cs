﻿using JewelryStore.Context;
using JewelryStore.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace JewelryStore.Services
{
    public class OAuthService : IOAuthService
    {
        private readonly IConfiguration _configuration;
        private readonly JewelryContext _jewelryContext;
        public OAuthService(IConfiguration configuration, JewelryContext jewelryContext)
        {
            _configuration = configuration;
            _jewelryContext = jewelryContext;
        }

        /// <summary>
        /// Validates user and Generats token
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">password</param>
        /// <returns></returns>
        public string ValidateAndGetToken(string userName, string password)
        {
            UserDetails users;
            try
            {
                 users = _jewelryContext.UserDetails.FirstOrDefault(x => x.UserName == userName && x.Password == password);

                if (users == null)
                {
                    return "Invalid credentials";
                }

            }
            catch (Exception)
            {
                throw;
               
            }
           
            return GetToken(users);
        }


        /// <summary>
        /// Generats Jwt Token
        /// </summary>
        /// <param name="users">Validated User </param>
        /// <returns>String</returns>
        public string GetToken(UserDetails users)
        {
            var key = Encoding.ASCII.GetBytes(_configuration.GetSection("Secret").ToString());
            var creds = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature);
            var claims = new Claim[] {
                new Claim(ClaimTypes.Name, users.Id.ToString()),
            new Claim(ClaimTypes.Role, users.Role.ToString())};
            var token = new JwtSecurityToken(
                issuer: "JewelryAdmin",
                audience: "JewelryApi",
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(15),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}

﻿using JewelryStore.Context;
using JewelryStore.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JewelryStore
{
    public class DataGenerator
    {
        public static void Init(IServiceProvider serviceProvider)
        {
            using (var context= new JewelryContext(serviceProvider.GetRequiredService<DbContextOptions<JewelryContext>>()))
            {
                if (context.UserDetails.Any() && context.Discount.Any())
                {
                    return;
                }
                context.UserDetails.AddRange(
                    new UserDetails {UserName = "privileged", Password="123", Role="Privileged" },
                    new UserDetails { UserName = "admin", Password = "123", Role = "Admin" },
                    new UserDetails { UserName = "normal", Password = "1234", Role = "Normal" });
                context.Discount.Add(
                    new Discount { UpdatedBy = "admin", UpdatedDate = DateTime.Now , DiscountPercent = 2 }   );

                context.SaveChanges();
            }
        }
    }
}

﻿using JewelryStore.Context;
using JewelryStore.Models;
using System;

namespace JewelryStore.Facades
{
    public class AdminFacade
    {
        /// <summary>
        /// Db Contest Class
        /// </summary>
        private readonly JewelryContext _jewelryContext;
        public AdminFacade(JewelryContext jewelryContext)
        {
            _jewelryContext = jewelryContext;
        }
           
        /// <summary>
        /// Updates Discount
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="discountPercent">discountPercent</param>
        /// <returns>string</returns>
        public string UpdateDiscount(string userName, int discountPercent)
        {
            try
            {
                _jewelryContext.Discount.Add(new Discount() { DiscountPercent = discountPercent,
                    UpdatedBy=userName,
                UpdatedDate=DateTime.Now});
                _jewelryContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw;
            }

            return "SuccessFully Updated";
        }
    }
}

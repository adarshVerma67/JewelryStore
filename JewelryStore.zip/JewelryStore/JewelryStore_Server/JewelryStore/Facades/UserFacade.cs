﻿using JewelryStore.Context;
using JewelryStore.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace JewelryStore.Facades
{
    public class UserFacade
    {
        /// <summary>
        /// Db Contest Class
        /// </summary>
        private readonly JewelryContext _jewelryContext;
        public UserFacade(JewelryContext jewelryContext)
        {
            _jewelryContext = jewelryContext;
        }

        /// <summary>
        /// Updates the Password after compairing with old credentials
        /// </summary>
        /// <param name="userName">userName</param>
        /// <param name="password">password</param>
        /// <param name="newPassword">new password</param>
        /// <returns>ActionResult<string></returns>
        public ActionResult<string> UpdatePassword(string userName, String password, String newPassword)
        {
            try
            {
                var userDetail = _jewelryContext.UserDetails.FirstOrDefault(x => x.UserName == userName && x.Password == password);
                if (userDetail == null)
                {
                    return "User Name or Password Doesnot Match";
                }

                userDetail.Password = newPassword;
                _jewelryContext.UserDetails.Update(userDetail);
                _jewelryContext.SaveChanges();
            }
            catch (Exception)
            {
                return "UnSuccessFul";
            }

            return "SuccessFul";
        }

        /// <summary>
        /// Gets the latest discount Percentage
        /// </summary>
        /// <returns>ActionResult<string></returns>
        public ActionResult<string> GetDiscount()
        {

            Discount discount;
            try
            {
                discount = _jewelryContext.Discount.Last();
            }
            catch (Exception)
            {
                throw;
            }

            return discount.DiscountPercent.ToString();
        }
    }
}

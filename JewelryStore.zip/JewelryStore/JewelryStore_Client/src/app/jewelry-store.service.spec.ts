import { of } from 'rxjs';

import { JewelryStoreService } from './jewelry-store.service';

describe('JewelryStoreService', () => {
  let service: JewelryStoreService;
  let httpClientSpy: { get: jasmine.Spy, post: jasmine.Spy };
  const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'

  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get','post']);
    service = new JewelryStoreService(httpClientSpy as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call login',() => {
    httpClientSpy.post.and.returnValue(of(token))
    service.login({}).subscribe(data => expect(data).toEqual(token));
  })

  it('should call getDiscount',() => {
    httpClientSpy.get.and.returnValue(of({value: 2}))
    service.getDiscount().subscribe((data:any) => expect(data.value).toEqual(2));
  })
});

import { ComponentFixture, TestBed } from '@angular/core/testing';
import { JewelryStoreService } from '../jewelry-store.service';
import { of } from 'rxjs';

import { EstimateComponent } from './estimate.component';
import { Router } from '@angular/router';

class StoreServiceStub{
  getDiscount(){
    return of({discount: 2})
  }
}
class MockRouter{
  navigate(url: string) {}
  params(){}
}

describe('EstimateComponent', () => {
  let component: EstimateComponent;
  let fixture: ComponentFixture<EstimateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EstimateComponent ],
      providers:[{provide: JewelryStoreService, useClass: StoreServiceStub },{provide: Router, useClass: MockRouter}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EstimateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch discount rate', ()=>{
    const storeService = TestBed.inject(JewelryStoreService)
    spyOn(storeService, 'getDiscount').and.returnValue(of({value:2}));
    component.fetchDiscount();
    expect(storeService.getDiscount).toHaveBeenCalled();
    expect(component.estimateForm.getRawValue().discount).toEqual(2);
  })

  it('should calculate total price', () => {
    const goldprice = 48000.67, weight = 20, discount = 0;
    const totalPrice = (goldprice*weight) - (discount/100)*(goldprice*weight);
    component.estimateForm.patchValue({
      goldPrice: goldprice,
      weight: weight,
      discount: discount
    })
    component.onCalculate();
    expect(component.estimateForm.getRawValue().totalPrice).toEqual(totalPrice.toFixed(2));
  })

  it('should generate and save a PDF file',() =>{
    const goldprice = 48000.67, weight = 20;
    component.estimateForm.patchValue({
      goldPrice: goldprice,
      weight: weight
    })
    spyOn(component, 'exportAsPDF').and.callFake(() => {});
    component.onCalculate();
    component.exportAsPDF();
    expect(component.exportAsPDF).toHaveBeenCalled();
  })

  it('should navigate to login on close', () => {
    const router = TestBed.inject(Router);
    spyOn(router, 'navigate').and.callThrough();
    component.onClose()
    expect(router.navigate).toHaveBeenCalled();
  })
});

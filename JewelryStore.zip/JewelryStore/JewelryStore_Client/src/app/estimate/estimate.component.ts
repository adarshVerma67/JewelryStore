import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { jsPDF } from 'jspdf';
import { JewelryStoreService } from '../jewelry-store.service';


@Component({
  selector: 'app-estimate',
  templateUrl: './estimate.component.html',
  styleUrls: ['./estimate.component.css']
})
export class EstimateComponent implements OnInit {
  estimateForm = new FormGroup({
    goldPrice: new FormControl(0,Validators.required),
    weight: new FormControl(0, Validators.required),
    totalPrice: new FormControl({value: 0, disabled: true}),
    discount:new FormControl({value: 0, disabled: true})
  })
  userRole = sessionStorage.getItem('role');
  constructor(
    private storeService: JewelryStoreService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    if(this.userRole === 'Privileged') this.fetchDiscount();
  }

  /**
   * Fetches dicount rate only for 'Privileged' user role
   */
  fetchDiscount(){
    this.storeService.getDiscount().subscribe((data: any) => {
      if(data){
        this.estimateForm.patchValue({
          discount: data.value
        })
      }else alert('Some Error Occured in fetching Discount!')
    },() => alert('Some Error Occured in fetching Discount!'))
  }

  /**
   * Calculates total price based on gold price per gram, weight of gold in gram and discount rate, if applicable
   */
  onCalculate(){
    if(this.estimateForm.valid){
      const estimate = this.estimateForm.getRawValue();
      const totalPrice = estimate.goldPrice * estimate.weight;
      this.estimateForm.patchValue({
        totalPrice: (totalPrice - ((estimate.discount/100) * totalPrice)).toFixed(2)
      })
    }
  }

  /**
   * Exports calculated result as a pdf receipt.
   */
  exportAsPDF()
  {
    const estimate = this.estimateForm.getRawValue();
    if(estimate.totalPrice){
    const doc = new jsPDF({
      orientation: 'portrait'
    });
    doc.setFontSize(14);
    doc.text('Gold price (per gram): ' + estimate.goldPrice , 20, 20);
    doc.text('Weight (grams): ' + estimate.weight , 20, 30);
    doc.text('Total Price: ' + estimate.totalPrice , 20, 40);
    if(this.userRole === 'Privileged') doc.text('Total Price: ' + estimate.discount , 20, 50);
    doc.save('estimate_'+(new Date).toLocaleString()+'.pdf');
  }else alert('Generate estimate first!');
    
  }

  /**
   * Clears token from browser and redirects to login page
   */
  onClose(){
    sessionStorage.clear();
    this.router.navigate(['/login'])
  }

}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JewelryStoreService {
  url = 'https://localhost:44342/api'
  constructor(private http: HttpClient) { }

  /**
   * API to authenticate user and get token.
   * @param credentials conatins username and password 
   */
  login(credentials: any){
    return this.http.post(this.url+'/Login', credentials, {responseType: 'text'});
 
  }
  
  /**
   * API call to fetch the discount rate.
   */
  getDiscount(){
    const header = new HttpHeaders({
      'Authorization': `bearer ${sessionStorage.getItem('token')}`
    })
    return this.http.get(this.url + '/Users',{headers: header})
  }
}

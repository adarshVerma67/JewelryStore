import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { JewelryStoreService } from '../jewelry-store.service';
import jwt_decode from "jwt-decode";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  loginForm = new FormGroup({
    userName: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  })
  constructor(
    private router: Router,
    private storeService: JewelryStoreService
  ) { }

  /**
   * Calls login API with user credentials and decodes token received in response to get role. Stores token and role in session storage
   */
  onClick(){
    if(this.loginForm.valid){
      this.storeService.login(this.loginForm.value).subscribe((response: string) => {
        if(response != "Invalid credentials"){
        sessionStorage.setItem('token', response);
        const token: any = jwt_decode(response);
        sessionStorage.setItem('role', token['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'])
        this.router.navigate(['/estimate'])}
        else alert('Invalid credentials!')
      }, () => {})
    }else alert('username and password required!')

  }

}

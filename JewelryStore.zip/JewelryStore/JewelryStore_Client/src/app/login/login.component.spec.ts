import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { JewelryStoreService } from '../jewelry-store.service';

import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'
  class StoreServiceStub {
    login(credentials: any){
    return of(token);
    }
  }
  
  class MockRouter{
    navigate(url: string) {}
    params(){}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      providers:[{provide: JewelryStoreService, useClass: StoreServiceStub },{provide: Router, useClass: MockRouter}],
      declarations: [ LoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call api to authenticate user', () => {
    const storeService = TestBed.inject(JewelryStoreService)
    spyOn(storeService, 'login').and.callThrough();
    component.loginForm.patchValue({
      userName: 'a',
      password: 'a'
    })
    component.onClick();
    expect(storeService.login).toHaveBeenCalled();
    expect(storeService.login).toHaveBeenCalledWith(component.loginForm.getRawValue());
  });

  it('should navigate to estimate screen', () => {
    const router = TestBed.inject(Router)
    const storeService = TestBed.inject(JewelryStoreService)
    spyOn(storeService, 'login').and.callThrough();
    spyOn(router, 'navigate').and.callThrough();
    component.loginForm.patchValue({
      userName: 'a',
      password: 'a'
    })
    component.onClick();
    expect(router.navigate).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledTimes(1);
  });

  it('sould not navigate to estimate page', () => {
    const router = TestBed.inject(Router)
    spyOn(router, 'navigate').and.callThrough();
    component.loginForm.patchValue({
      userName: '',
      password: ''
    })
    component.onClick();
    expect(router.navigate).not.toHaveBeenCalled();
  });
});
